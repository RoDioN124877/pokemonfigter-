// src/services/ApiService.ts

import type { Pokemon, PokemonStat } from '../types/Pokemon';

export const BATCH_SIZE = 50;
export const INITIAL_LOAD_COUNT = 100; // Начнем с 100

const getStatsMap = (stats: PokemonStat[]): Record<string, number> => {
    return stats.reduce((acc, s) => {
        acc[s.stat.name] = s.base_stat;
        return acc;
    }, {} as Record<string, number>);
};

const processPokemonData = (pok: any): Pokemon => {
    // 💡 Вам нужно добавить height, weight и abilities в интерфейс Pokemon в types/Pokemon.ts
    return {
        id: pok.id,
        name: pok.name,
        types: pok.types,
        sprites: pok.sprites,
        statsMap: getStatsMap(pok.stats) as Pokemon['statsMap'],
        height: pok.height, // Ошибка пропадет после обновления типа Pokemon
        weight: pok.weight, // Ошибка пропадет после обновления типа Pokemon
        stats: pok.stats,
        abilities: pok.abilities, // Ошибка пропадет после обновления типа Pokemon
    };
};

// ... (fetchPokemonsBatch без изменений) ...
export async function fetchPokemonsBatch(startId: number, count: number = BATCH_SIZE): Promise<Pokemon[]> {
    const promises = [];
    const endId = startId + count - 1;

    for (let i = startId; i <= endId; i++) {
        promises.push(
            fetch(`https://pokeapi.co/api/v2/pokemon/${i}`)
                .then(r => {
                    if (r.status === 404) return null;
                    return r.json();
                })
                .catch(() => null) // Игнорируем ошибки (напр. 404 для несуществующих ID)
        );
    }

    const data = await Promise.all(promises);

    return data.filter(Boolean).map(processPokemonData);
}