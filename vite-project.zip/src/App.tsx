// src/App.tsx

import React, { useState, useEffect } from 'react';
import type { AppState, Pokemon } from './types/Pokemon';
import { fetchPokemonsBatch, INITIAL_LOAD_COUNT } from './services/ApiService'; // <-- ИМПОРТИРУЕМ БАТЧ-ФУНКЦИЮ
import Menu from './components/Menu';
import Selection from './components/Selection';
import BattleArena from './components/BattleArena';

// Расширенное начальное состояние
const initialAppState: AppState & { nextPokemonIdToLoad: number } = {
    allPokemons: [],
    team1: [],
    team2: [],
    maxTeamSize: 1,
    currentMode: 'menu', 
    nextPokemonIdToLoad: INITIAL_LOAD_COUNT + 1, // Начинаем со следующего ID
};

function App() {
    const [state, setState] = useState<typeof initialAppState>(initialAppState);
    
    // Эффект для начальной загрузки данных
    useEffect(() => {
        const loadInitialData = async () => {
            const poks = await fetchPokemonsBatch(1, INITIAL_LOAD_COUNT); 
            setState(prev => ({ 
                ...prev, 
                allPokemons: poks,
                nextPokemonIdToLoad: INITIAL_LOAD_COUNT + 1
            }));
        };
        loadInitialData();
    }, []);

    // НОВАЯ ФУНКЦИЯ: Динамическая подгрузка
    const loadMorePokemons = async () => {
        const newPoks = await fetchPokemonsBatch(state.nextPokemonIdToLoad);
        if (newPoks.length > 0) {
            setState(prev => ({
                ...prev,
                allPokemons: [...prev.allPokemons, ...newPoks],
                nextPokemonIdToLoad: prev.nextPokemonIdToLoad + newPoks.length,
            }));
        }
    };
    
    // ... (setMode, selectFighter, startBattle - без существенных изменений) ...
    
    // Рендеринг в зависимости от текущего режима
    const renderScreen = () => {
        switch (state.currentMode) {
            case 'menu':
                return <Menu setMode={setMode} />;
            case 'selection':
                return (
                    <Selection 
                        allPokemons={state.allPokemons}
                        team1={state.team1}
                        team2={state.team2}
                        maxSize={state.maxTeamSize}
                        selectFighter={selectFighter}
                        startBattle={startBattle}
                        goToMenu={() => setState({...initialAppState, allPokemons: state.allPokemons})}
                        loadMorePokemons={loadMorePokemons} // <-- Передаем новую функцию
                    />
                );
            case 'battle':
                // ... (BattleArena render remains the same)
        }
    };

    return (
        <div className="App">
            {renderScreen()}
        </div>
    );
}

export default App;